# Retail Project > 2023-10-20 7:53am
https://universe.roboflow.com/pcb-detection/retail-project-rtg1x

Provided by a Roboflow user
License: MIT

